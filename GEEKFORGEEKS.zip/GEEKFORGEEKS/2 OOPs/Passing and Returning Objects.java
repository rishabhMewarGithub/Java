
Passing and Returning Objects

Although Java is strictly pass by value, the precise effect differs between whether a primitive type or a reference type is passed.
When we pass a primitive type to a method, it is passed by value. 
But when we pass an object to a method, it is effectively call-by-reference. 
Java does this interesting thing that’s sort of a hybrid between pass-by-value and pass-by-reference. 
Basically, a parameter cannot be changed by the function, but the function can ask the parameter to change itself via calling some method within it.

While creating a variable of a class type, we only create a reference to an object. 
Thus, when we pass this reference to a method, the parameter that receives it will refer to the same object as that referred to by the argument.
This effectively means that objects act as if they are passed to methods by use of call-by-reference.
Changes to the object inside the method do reflect in the object used as an argument.

// Java program to demonstrate objects passing to methods. 

class ObjectPassDemo 
{ 
	int a, b; 

	ObjectPassDemo(int i, int j) 
	{ 
		a = i; 
		b = j; 
	} 

	// return true if o is equal to the invoking object 
	// notice an object is passed as an argument to method 
	boolean equalTo(ObjectPassDemo o) 
	{ 
		return (o.a == a && o.b == b); 
	} 
} 

// Driver class 
public class Test 
{ 
	public static void main(String args[]) 
	{ 
		ObjectPassDemo ob1 = new ObjectPassDemo(100, 22); 
		ObjectPassDemo ob2 = new ObjectPassDemo(100, 22); 
		ObjectPassDemo ob3 = new ObjectPassDemo(-1, -1); 

		System.out.println("ob1 == ob2: " + ob1.equalTo(ob2)); 
		System.out.println("ob1 == ob3: " + ob1.equalTo(ob3)); 
	} 
} 


Defining a constructor that takes an object of its class as a parameter
One of the most common uses of object parameters involves constructors. 
Frequently, in practice, there is need to construct a new object so that it is initially the same as some existing object. 
To do this, either we can use Object.clone() method or define a constructor that takes an object of its class as a parameter. 
The second option is illustrated in below example:

// Java program to demonstrate one object to 
// initialize another 
class Box 
{ 
	double width, height, depth; 

	// Notice this constructor. It takes an 
	// object of type Box. This constructor use 
	// one object to initialize another 
	Box(Box ob) 
	{ 
		width = ob.width; 
		height = ob.height; 
		depth = ob.depth; 
	} 

	// constructor used when all dimensions 
	// specified 
	Box(double w, double h, double d) 
	{ 
		width = w; 
		height = h; 
		depth = d; 
	} 

	// compute and return volume 
	double volume() 
	{ 
		return width * height * depth; 
	} 
} 

// driver class 
public class Test 
{ 
	public static void main(String args[]) 
	{ 
		// creating a box with all dimensions specified 
		Box mybox = new Box(10, 20, 15); 

		// creating a copy of mybox 
		Box myclone = new Box(mybox); 

		double vol; 

		// get volume of mybox 
		vol = mybox.volume(); 
		System.out.println("Volume of mybox is " + vol); 

		// get volume of myclone 
		vol = myclone.volume(); 
		System.out.println("Volume of myclone is " + vol); 
	} 
} 


Returning Objects
In java, a method can return any type of data, including objects. 
For example, in the following program, the incrByTen( ) method returns an object in which the value of a (an integer variable) is ten greater than it is in the invoking object.

// Java program to demonstrate returning 
// of objects 
class ObjectReturnDemo 
{ 
	int a; 

	ObjectReturnDemo(int i) 
	{ 
		a = i; 
	} 

	// This method returns an object 
	ObjectReturnDemo incrByTen() 
	{ 
		ObjectReturnDemo temp = 
			new ObjectReturnDemo(a+10); 
		return temp; 
	} 
} 

// Driver class 
public class Test 
{ 
	public static void main(String args[]) 
	{ 
		ObjectReturnDemo ob1 = new ObjectReturnDemo(2); 
		ObjectReturnDemo ob2; 

		ob2 = ob1.incrByTen(); 

		System.out.println("ob1.a: " + ob1.a); 
		System.out.println("ob2.a: " + ob2.a); 
	} 
} 

When an object reference is passed to a method, the reference itself is passed by use of call-by-value. 
However, since the value being passed refers to an object, the copy of that value will still refer to the same object that its corresponding argument does. 
That’s why we said that java is strictly pass-by-value.


















































































