

Class
A class is a user defined blueprint or prototype from which objects are created.  
It represents the set of properties or methods that are common to all objects of one type. 
Constructors are used for initializing new objects. 
Fields are variables that provides the state of the class and its objects, and methods are used to implement the behavior of the class and its objects.

Object
It is a basic unit of Object Oriented Programming and represents the real life entities.  A typical Java program creates many objects, which as you know, interact by invoking methods. 
An object consists of :
State    : It is represented by attributes of an object. It also reflects the properties of an object.
Behavior : It is represented by methods of an object. It also reflects the response of an object with other objects.
Identity : It gives a unique name to an object and enables one object to interact with other objects.

Declaring Objects (Also called instantiating a class)
When an object of a class is created, the class is said to be instantiated. 
All the instances share the attributes and the behavior of the class. 
But the values of those attributes, i.e. the state are unique for each object. 
A single class may have any number of instances.

So for reference variable, type must be strictly a concrete class name. In general,we can’t create objects of an abstract class or an interface.
Dog tuffy;
If we declare reference variable(tuffy) like this, its value will be undetermined(null) until an object is actually created and assigned to it. 
Simply declaring a reference variable does not create an object.

Initializing an object
The new operator instantiates a class by allocating memory for a new object and returning a reference to that memory. 
The new operator also invokes the class constructor.

// Class Declaration 

public class Dog 
{ 
	// Instance Variables 
	String name; 
	String breed; 
	int age; 
	String color; 

	// Constructor Declaration of Class 
	public Dog(String name, String breed, int age, String color) 
	{ 
		this.name = name; 
		this.breed = breed; 
		this.age = age; 
		this.color = color; 
	} 

	// method 1 
	public String getName() 
	{ 
		return name; 
	} 

	// method 2 
	public String getBreed() 
	{ 
		return breed; 
	} 

	// method 3 
	public int getAge() 
	{ 
		return age; 
	} 

	// method 4 
	public String getColor() 
	{ 
		return color; 
	} 

	@Override
	public String toString() 
	{ 
		return("Hi my name is "+ this.getName()+ 
			".\nMy breed,age and color are " + 
			this.getBreed()+"," + this.getAge()+ 
			","+ this.getColor()); 
	} 

	public static void main(String[] args) 
	{ 
		Dog tuffy = new Dog("tuffy","papillon", 5, "white"); 
		System.out.println(tuffy.toString()); 
	} 
} 

The Java compiler differentiates the constructors based on the number and the type of the arguments. 

All classes have at least one constructor. 
If a class does not explicitly declare any, the Java compiler automatically provides a no-argument constructor, also called the default constructor. 
This default constructor calls the class parent’s no-argument constructor (as it contain only one statement i.e super();), 
or the Object class constructor if the class has no other parent (as Object class is parent of all classes either directly or indirectly).

Creating multiple objects by one type only (A good practice)
In real-time, we need different objects of a class in different methods. 
Creating a number of references for storing them is not a good practice and therefore we declare a static reference variable and use it whenever required. 
In this case,wastage of memory is less. 
The objects that are not referenced anymore will be destroyed by Garbage Collector of java. 
Example:
Test test = new Test();
test = new Test();

In inheritance system, we use parent class reference variable to store a sub-class object. 
In this case, we can switch into different subclass objects using same referenced variable. 
Example:

class Animal {}
class Dog extends Animal {}
class Cat extends Animal {}

public class Test
{
    // using Dog object
    Animal obj = new Dog();

    // using Cat object
    obj = new Cat();
}       


Anonymous objects
Anonymous objects are the objects that are instantiated but are not stored in a reference variable.
They are used for immediate method calling.
They will be destroyed after method calling.
They are widely used in different libraries. For example, in AWT libraries, they are used to perform some action on capturing an event(eg a key press).

In example below, when a key is button(referred by the btn) is pressed, we are simply creating anonymous object of EventHandler class for just calling handle method.
btn.setOnAction(new EventHandler()
{
    public void handle(ActionEvent event)
    {
        System.out.println("Hello World!");
    }
});
















class Outer { 
// Simple nested inner class 
	class Inner { 
		public void show() { 
			System.out.println("In a nested class method"); 
		} 
	} 
} 
class Main { 
	public static void main(String[] args) { 
		Outer.Inner in = new Outer().new Inner(); 
		in.show(); 
	} 
} 


class Outer { 
	void outerMethod() { 
		System.out.println("inside outerMethod"); 
		// Inner class is local to outerMethod() 
		class Inner { 
			void innerMethod() { 
				System.out.println("inside innerMethod"); 
			} 
		} 
		Inner y = new Inner(); 
		y.innerMethod(); 
	} 
} 
class MethodDemo { 
	public static void main(String[] args) { 
		Outer x = new Outer(); 
		x.outerMethod(); 
	} 
} 



class Outer { 
	private static void outerMethod() { 
		System.out.println("inside outerMethod"); 
	} 
	
	// A static inner class 
	static class Inner { 
		public static void main(String[] args) { 
			System.out.println("inside inner class Method"); 
			outerMethod(); 
		} 
	} 
}


class Demo { 
	void show() { 
		System.out.println("i am in show method of super class"); 
	} 
} 
class Flavor1Demo { 

	// An anonymous class with Demo as base class 
	static Demo d = new Demo() { 
		void show() { 
			super.show(); 
			System.out.println("i am in Flavor1Demo class"); 
		} 
	}; 
	public static void main(String[] args){ 
		d.show(); 
	} 
}



class Flavor2Demo { 

	// An anonymous class that implements Hello interface 
	static Hello h = new Hello() { 
		public void show() { 
			System.out.println("i am in anonymous class"); 
		} 
	}; 

	public static void main(String[] args) { 
		h.show(); 
	} 
} 

interface Hello { 
	void show(); 
} 



// Java program to demonstrate accessing 
// a static nested class 

// outer class 
class OuterClass 
{ 
	// static member 
	static int outer_x = 10; 
	
	// instance(non-static) member 
	int outer_y = 20; 
	
	// private member 
	private static int outer_private = 30; 
	
	// static nested class 
	static class StaticNestedClass 
	{ 
		void display() 
		{ 
			// can access static member of outer class 
			System.out.println("outer_x = " + outer_x); 
			
			// can access display private static member of outer class 
			System.out.println("outer_private = " + outer_private); 
			
			// The following statement will give compilation error 
			// as static nested class cannot directly access non-static membera 
			// System.out.println("outer_y = " + outer_y); 
		
		} 
	} 
} 

// Driver class 
public class StaticNestedClassDemo 
{ 
	public static void main(String[] args) 
	{ 
		// accessing a static nested class 
		OuterClass.StaticNestedClass nestedObject = new OuterClass.StaticNestedClass(); 
		
		nestedObject.display(); 
		
	} 
} 




// Java program to demonstrate accessing a inner class 

// outer class 
class OuterClass 
{ 
	// static member 
	static int outer_x = 10; 
	
	// instance(non-static) member 
	int outer_y = 20; 
	
	// private member 
	private int outer_private = 30; 
	
	// inner class 
	class InnerClass 
	{ 
		void display() 
		{ 
			// can access static member of outer class 
			System.out.println("outer_x = " + outer_x); 
			
			// can also access non-static member of outer class 
			System.out.println("outer_y = " + outer_y); 
			
			// can also access private member of outer class 
			System.out.println("outer_private = " + outer_private); 
		
		} 
	} 
} 

// Driver class 
public class InnerClassDemo 
{ 
	public static void main(String[] args) 
	{ 
		// accessing an inner class 
		OuterClass outerObject = new OuterClass(); 
		OuterClass.InnerClass innerObject = outerObject.new InnerClass(); 
		
		innerObject.display(); 
		
	} 
} 



// Java program to illustrate 
// working of local inner classes 
public class Outer 
{ 
	private void getValue() 
	{ 
		// Note that local variable(sum) must be final till JDK 7 
		// hence this code will work only in JDK 8 
		int sum = 20; 
		
		// Local inner Class inside method 
		class Inner 
		{ 
			public int divisor; 
			public int remainder; 
			
			public Inner() 
			{ 
				divisor = 4; 
				remainder = sum%divisor; 
			} 
			private int getDivisor() 
			{ 
				return divisor; 
			} 
			private int getRemainder() 
			{ 
				return sum%divisor; 
			} 
			private int getQuotient() 
			{ 
				System.out.println("Inside inner class"); 
				return sum / divisor; 
			} 
		} 
		
		Inner inner = new Inner(); 
		System.out.println("Divisor = "+ inner.getDivisor()); 
		System.out.println("Remainder = " + inner.getRemainder()); 
		System.out.println("Quotient = " + inner.getQuotient()); 
	} 
	
	public static void main(String[] args) 
	{ 
		Outer outer = new Outer(); 
		outer.getValue(); 
	} 
} 



// Java program to illustrate Declaration of 
// local inner classes inside an if statement 
public class Outer 
{ 
	public int data = 10; 
	public int getData() 
	{ 
		return data; 
	} 
	public static void main(String[] args) 
	{ 
		Outer outer = new Outer(); 
		
		if(outer.getData() < 20) 
		{ 
			// Local inner class inside if clause 
			class Inner 
			{ 
				public int getValue() 
				{ 
					System.out.println("Inside Inner class"); 
					return outer.data; 
				} 
			} 

			Inner inner = new Inner(); 
			System.out.println(inner.getValue()); 
		} 
		else
		{ 
			System.out.println("Inside Outer class"); 
		} 
	} 
} 



// Java code to demonstrate that inner 
// classes cannot be declared as static 
public class Outer 
{ 
	private int getValue(int data) 
	{ 
		static class Inner 
		{ 
			private int getData() 
			{ 
				System.out.println("Inside inner class"); 
				if(data < 10) 
				{ 
					return 5; 
				} 
				else
				{ 
					return 15; 
				} 
			} 
		} 
		
		Inner inner = new Inner(); 
		return inner.getData(); 
	} 
	
	public static void main(String[] args) 
	{ 
		Outer outer = new Outer(); 
		System.out.println(outer.getValue(10)); 
	} 
} 



// Java code to demonstrate 
// the scope of inner class 
public class Outer 
{ 
	private void myMethod() 
	{ 
		class Inner 
		{ 
			private void innerMethod() 
			{ 
				System.out.println("Inside inner class"); 
			} 
		} 
	} 
	
	public static void main(String[] args) 
	{ 
		Outer outer = new Outer(); 
		Inner inner = new Inner(); 
		System.out.println(inner.innerMethod()); 
	} 
} 