

/**************************************** Overriding in Java *************************************************/


Overriding is a feature that allows a subclass or child class to provide a specific implementation of a method that is already provided by one of its super-classes or parent classes. 
When a method in a subclass has the same name, same parameters or signature and same return type(or sub-type) as a method in its super-class, then the method 
in the subclass is said to override the method in the super-class.

Method overriding is one of the way by which java achieve Run Time Polymorphism.
The version of a method that is executed will be determined by the object that is used to invoke it. 
If an object of a parent class is used to invoke the method, then the version in the parent class will be executed, but if an object of the subclass is used to invoke the method, 
then the version in the child class will be executed. 
In other words, it is the type of the object being referred to (not the type of the reference variable) that determines which version of an overridden method will be executed.


// A Simple Java program to demonstrate 
// method overriding in java 

// Base Class 
class Parent { 
	void show() 
	{ 
		System.out.println("Parent's show()"); 
	} 
} 

// Inherited class 
class Child extends Parent { 
	// This method overrides show() of Parent 
	@Override
	void show() 
	{ 
		System.out.println("Child's show()"); 
	} 
} 

// Driver class 
class Main { 
	public static void main(String[] args) 
	{ 
		// If a Parent type reference refers 
		// to a Parent object, then Parent's 
		// show is called 
		Parent obj1 = new Parent(); 
		obj1.show(); 

		// If a Parent type reference refers 
		// to a Child object Child's show() 
		// is called. This is called RUN TIME 
		// POLYMORPHISM. 
		Parent obj2 = new Child(); 
		obj2.show(); 
	} 
} 


/** 
	Output:
		Parent's show()
		Child's show()
**/


/************************** Rules for method overriding: ************************************/


Overriding and Access-Modifiers : 	The access modifier for an overriding method can allow more, but not less, access than the overridden method. 
									For example, a protected instance method in the super-class can be made public, but not private, in the subclass. 
									Doing so, will generate compile-time error.


// A Simple Java program to demonstrate 
// Overriding and Access-Modifiers 

class Parent { 
	// private methods are not overridden 
	private void m1() 
	{ 
		System.out.println("From parent m1()"); 
	} 

	protected void m2() 
	{ 
		System.out.println("From parent m2()"); 
	} 
} 

class Child extends Parent { 
	// new m1() method 
	// unique to Child class 
	private void m1() 
	{ 
		System.out.println("From child m1()"); 
	} 

	// overriding method 
	// with more accessibility 
	@Override
	public void m2() 
	{ 
		System.out.println("From child m2()"); 
	} 
} 

// Driver class 
class Main { 
	public static void main(String[] args) 
	{ 
		Parent obj1 = new Parent(); 
		obj1.m2(); 
		Parent obj2 = new Child(); 
		obj2.m2(); 
	} 
} 

/** 
Output:
From parent m2()
From child m2()
**/


Final methods can not be overridden : If we don’t want a method to be overridden, we declare it as final. Please see Using final with Inheritance .

// A Java program to demonstrate that 
// final methods cannot be overridden 

class Parent { 
	// Can't be overridden 
	final void show() {} 
} 

class Child extends Parent { 
	// This would produce error 
	void show() {} 
} 


Static methods can not be overridden(Method Overriding vs Method Hiding) : 	When you defines a static method with same signature as a static method in base class, 
																			it is known as method hiding.


							SUPERCLASS INSTANCE METHOD			SUPERCLASS STATIC METHOD
SUBCLASS INSTANCE METHOD	Overrides							Generates a compile-time error
SUBCLASS STATIC METHOD		Generates a compile-time error		Hides


// Java program to show that 
// if the static method is redefined by 
// a derived class, then it is not 
// overriding, it is hiding 

class Parent { 
	// Static method in base class 
	// which will be hidden in subclass 
	static void m1() 
	{ 
		System.out.println("From parent "
						+ "static m1()"); 
	} 

	// Non-static method which will 
	// be overridden in derived class 
	void m2() 
	{ 
		System.out.println("From parent "
						+ "non-static(instance) m2()"); 
	} 
} 

class Child extends Parent { 
	// This method hides m1() in Parent 
	static void m1() 
	{ 
		System.out.println("From child static m1()"); 
	} 

	// This method overrides m2() in Parent 
	@Override
	public void m2() 
	{ 
		System.out.println("From child "
						+ "non-static(instance) m2()"); 
	} 
} 

// Driver class 
class Main { 
	public static void main(String[] args) 
	{ 
		Parent obj1 = new Child(); 

		// As per overriding rules this 
		// should call to class Child static 
		// overridden method. Since static 
		// method can not be overridden, it 
		// calls Parent's m1() 
		obj1.m1(); 

		// Here overriding works 
		// and Child's m2() is called 
		obj1.m2(); 
	} 
} 

/**Output:
From parent static m1()
From child non-static(instance) m2()**/


Private methods can not be overridden : Private methods cannot be overridden as they are bonded during compile time. 
										Therefore we can’t even override private methods in a subclass.(See this for details).

class Base { 
	public void fun() { 
		System.out.println("Base fun");	 
	} 
} 
	
class Derived extends Base { 
	public void fun() { // overrides the Base's fun() 
		System.out.println("Derived fun"); 
	} 
	public static void main(String[] args) { 
		Base obj = new Derived(); 
		obj.fun(); 
	} 
}

/*The program prints “Derived fun”.
The Base class reference ‘obj’ refers to a derived class object (see expression “Base obj = new Derived()”). 
When fun() is called on obj, the call is made according to the type of referred object, not according to the reference.*/

class Base { 
	private void fun() { 
		System.out.println("Base fun");	 
	} 
} 
	
class Derived extends Base { 
	private void fun() { 
		System.out.println("Derived fun"); 
	} 
	public static void main(String[] args) { 
		Base obj = new Derived(); 
		obj.fun(); 
	} 
}

/*We get compiler error “fun() has private access in Base”*/


/* Java program to demonstrate whether we can override private method 
   of outer class inside its inner class */
   
class Outer { 
	private String msg = "GeeksforGeeks"; 
	private void fun() { 
		System.out.println("Outer fun()"); 
	} 

	class Inner extends Outer { 
		private void fun() { 
			System.out.println("Accessing Private Member of Outer: " + msg); 
		} 
	} 

	public static void main(String args[]) { 

		// In order to create instance of Inner class, we need an Outer 
		// class instance. So, first create Outer class instance and then 
		// inner class instance. 
		Outer o = new Outer(); 
		Inner i = o.new Inner(); 
			
		// This will call Inner's fun, the purpose of this call is to 
		// show that private members of Outer can be accessed in Inner. 
		i.fun(); 

		// o.fun() calls Outer's fun (No run-time polymorphism). 
		o = i; 
		o.fun(); 
	} 
} 

/*If we observe our output, then it is clear that the method fun() has not been overridden. It is so because private methods are bonded during compile time and it is the type 
of the reference variable – not the type of object that it refers to – that determines what method to be called.. As a side note, private methods may be performance-wise better 
(compared to non-private and non-final methods) due to static binding.*/





























