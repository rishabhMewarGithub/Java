

//Using final with inheritance

/**
During inheritance, we must declare methods with final keyword for which we required to follow the same implementation throughout all the derived classes. 
Note that it is not necessary to declare final methods in the initial stage of inheritance(base class always). We can declare final method in any subclass for 
which we want that if any other class extends this subclass, then it must follow same implementation of the method as in the that subclass.
**/


// Java program to illustrate 
// use of final with inheritance 

// base class 
abstract class Shape 
{ 
	private double width; 
	
	private double height; 
	
	// Shape class parameterized constructor 
	public Shape(double width, double height) 
	{ 
		this.width = width; 
		this.height = height; 
	} 
	
	// getWidth method is declared as final 
	// so any class extending 
	// Shape cann't override it 
	public final double getWidth() 
	{ 
		return width; 
	} 
	
	// getHeight method is declared as final 
	// so any class extending Shape 
	// can not override it 
	public final double getHeight() 
	{ 
		return height; 
	} 


	// method getArea() declared abstract because 
	// it upon its subclasses to provide 
	// complete implementation 
	abstract double getArea(); 
} 

// derived class one 
class Rectangle extends Shape 
{ 
	// Rectangle class parameterized constructor 
	public Rectangle(double width, double height) 
	{ 
		// calling Shape class constructor 
		super(width, height); 
	} 

	// getArea method is overridden and declared 
	// as final so any class extending 
	// Rectangle cann't override it 
	@Override
	final double getArea() 
	{ 
		return this.getHeight() * this.getWidth(); 
	} 
	
} 

//derived class two 
class Square extends Shape 
{ 
	// Square class parameterized constructor 
	public Square(double side) 
	{ 
		// calling Shape class constructor 
		super(side, side); 
	} 

	// getArea method is overridden and declared as 
	// final so any class extending 
	// Square cann't override it 
	@Override
	final double getArea() 
	{ 
		return this.getHeight() * this.getWidth(); 
	} 
	
} 

// Driver class 
public class Test 
{ 
	public static void main(String[] args) 
	{ 
		// creating Rectangle object 
		Shape s1 = new Rectangle(10, 20); 
		
		// creating Square object 
		Shape s2 = new Square(10); 
		
		// getting width and height of s1 
		System.out.println("width of s1 : "+ s1.getWidth()); 
		System.out.println("height of s1 : "+ s1.getHeight()); 
		
		// getting width and height of s2 
		System.out.println("width of s2 : "+ s2.getWidth()); 
		System.out.println("height of s2 : "+ s2.getHeight()); 
		
		//getting area of s1 
		System.out.println("area of s1 : "+ s1.getArea()); 
		
		//getting area of s2 
		System.out.println("area of s2 : "+ s2.getArea()); 
		
	} 
} 

/**Output:

width of s1 : 10.0
height of s1 : 20.0
width of s2 : 10.0
height of s2 : 10.0
area of s1 : 200.0
area of s2 : 100.0**/


//Using final to Prevent Inheritance

//When a class is declared as final then it cannot be subclassed i.e. no any other class can extend it. 
//This is particularly useful, for example, when creating an immutable class like the predefined String class. The following fragment illustrates final keyword with a class:

final class A
{
     // methods and fields
}
// The following class is illegal.
class B extends A 
{ 
    // ERROR! Can't subclass A
}

//Note :
//Declaring a class as final implicitly declares all of its methods as final, too.
//It is illegal to declare a class as both abstract and final since an abstract class is incomplete by itself and relies upon its subclasses to provide complete implementations.


//Using final to Prevent Overriding

//When a method is declared as final then it cannot be overridden by subclasses.The Object class does this—a number of its methods are final. 
//The following fragment illustrates final keyword with a method:

class A 
{
    final void m1() 
    {
        System.out.println("This is a final method.");
    }
}

class B extends A 
{
    void m1()
    { 
        // ERROR! Can't override.
        System.out.println("Illegal!");
    }
}


//Normally, Java resolves calls to methods dynamically, at run time. This is called late or dynamic binding. However, since final methods cannot be overridden, a call 
//to one can be resolved at compile time. This is called early or static binding.

























































































