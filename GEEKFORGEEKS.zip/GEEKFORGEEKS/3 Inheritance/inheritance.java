

/*********************************** How to use inheritance in Java *****************************/

//Java program to illustrate the concept of inheritance 

// base class 
class Bicycle 
{ 
	// the Bicycle class has two fields 
	public int gear; 
	public int speed; 
		
	// the Bicycle class has one constructor 
	public Bicycle(int gear, int speed) 
	{ 
		this.gear = gear; 
		this.speed = speed; 
	} 
		
	// the Bicycle class has three methods 
	public void applyBrake(int decrement) 
	{ 
		speed -= decrement; 
	} 
		
	public void speedUp(int increment) 
	{ 
		speed += increment; 
	} 
	
	// toString() method to print info of Bicycle 
	public String toString() 
	{ 
		return("No of gears are "+gear 
				+"\n"
				+ "speed of bicycle is "+speed); 
	} 
} 

// derived class 
class MountainBike extends Bicycle 
{ 
	
	// the MountainBike subclass adds one more field 
	public int seatHeight; 

	// the MountainBike subclass has one constructor 
	public MountainBike(int gear,int speed, int startHeight) 
	{ 
		// invoking base-class(Bicycle) constructor 
		super(gear, speed); 
		seatHeight = startHeight; 
	} 
		
	// the MountainBike subclass adds one more method 
	public void setHeight(int newValue) 
	{ 
		seatHeight = newValue; 
	} 
	
	// overriding toString() method 
	// of Bicycle to print more info 
	@Override
	public String toString() 
	{ 
		return (super.toString()+ 
				"\n seat height is " +seatHeight); 
	} 
	
} 

// driver class 
public class Test 
{ 
	public static void main(String args[]) 
	{ 
		MountainBike mb = new MountainBike(3, 100, 25); 
		System.out.println(mb.toString()); 
			
	} 
} 

/**	
	Output:
		No of gears are 3
		speed of bicycle is 100
		seat height is 25 
**/

// Please note that during inheritance only object of subclass is created, not the superclass. 
// inheritance and polymorphism are used together in java to achieve fast performance and readability of code.



/***************************** Java Object Creation of Inherited Class *********************************/


/*This situation is different from a normal assumption that a constructor call means an object of the class is created, 
so we can’t blindly say that whenever a class constructor is executed, object of that class is created or not.*/


// A Java program to demonstrate that both super class and subclass constructors refer to same object 

// super class 
class Fruit 
{ 
	public Fruit() 
	{ 
		System.out.println("Super class constructor"); 
		System.out.println("Super class object hashcode :" +this.hashCode()); 
		System.out.println(this.getClass().getName()); 
	} 
} 

// sub class 
class Apple extends Fruit 
{ 
	public Apple() 
	{ 
		System.out.println("Subclass constructor invoked"); 
		System.out.println("Sub class object hashcode :" +this.hashCode()); 
		System.out.println(this.hashCode() + " " +super.hashCode()); 
		System.out.println(this.getClass().getName() + " " +super.getClass().getName()); 
	} 
} 

// driver class 
public class Test 
{ 
	public static void main(String[] args) 
	{ 
		Apple myApple = new Apple(); 
	} 
} 


/** 
Output:
	super class constructor 
	super class object hashcode :366712642
	Apple
	sub class constructor 
	sub class object hashcode :366712642
	366712642   366712642
	Apple  Apple
**/



/**************************************** Types of Inheritance in Java ***************************************/


// 1. Single Inheritance : In single inheritance, subclasses inherit the features of one superclass.

//Java program to illustrate the 
// concept of single inheritance 
import java.util.*; 
import java.lang.*; 
import java.io.*; 

class one 
{ 
	public void print_geek() 
	{ 
		System.out.println("Geeks"); 
	} 
} 

class two extends one 
{ 
	public void print_for() 
	{ 
		System.out.println("for"); 
	} 
} 
// Driver class 
public class Main 
{ 
	public static void main(String[] args) 
	{ 
		two g = new two(); 
		g.print_geek(); 
		g.print_for(); 
		g.print_geek(); 
	} 
} 
/*Output:
Geeks
for
Geeks*/


// 2. Multilevel Inheritance : In Multilevel Inheritance, a derived class will be inheriting a base class and as well as the derived class also act as the base class to other class. 

// Java program to illustrate the 
// concept of Multilevel inheritance 
import java.util.*; 
import java.lang.*; 
import java.io.*; 

class one 
{ 
	public void print_geek() 
	{ 
		System.out.println("Geeks"); 
	} 
} 

class two extends one 
{ 
	public void print_for() 
	{ 
		System.out.println("for"); 
	} 
} 

class three extends two 
{ 
	public void print_geek() 
	{ 
		System.out.println("Geeks"); 
	} 
} 

// Drived class 
public class Main 
{ 
	public static void main(String[] args) 
	{ 
		three g = new three(); 
		g.print_geek(); 
		g.print_for(); 
		g.print_geek(); 
	} 
} 

/*
Output:
Geeks
for
Geeks
*/

// 3. Hierarchical Inheritance : In Hierarchical Inheritance, one class serves as a superclass (base class) for more than one sub class.

// Java program to illustrate the 
// concept of Hierarchical inheritance 
import java.util.*; 
import java.lang.*; 
import java.io.*; 

class one 
{ 
	public void print_geek() 
	{ 
		System.out.println("Geeks"); 
	} 
} 

class two extends one 
{ 
	public void print_for() 
	{ 
		System.out.println("for"); 
	} 
} 

class three extends one 
{ 
	/*............*/
} 

// Drived class 
public class Main 
{ 
	public static void main(String[] args) 
	{ 
		three g = new three(); 
		g.print_geek(); 
		two t = new two(); 
		t.print_for(); 
		g.print_geek(); 
	} 
} 

/*
Output:
Geeks
for
Geeks

*/


// 4. Multiple Inheritance (Through Interfaces) : In Multiple inheritance ,one class can have more than one superclass and inherit features from all parent classes. 
//    Please note that Java does not support multiple inheritance with classes. In java, we can achieve multiple inheritance only through Interfaces. 

// Java program to illustrate the 
// concept of Multiple inheritance 
import java.util.*; 
import java.lang.*; 
import java.io.*; 

interface one 
{ 
	public void print_geek(); 
} 

interface two 
{ 
	public void print_for(); 
} 

interface three extends one,two 
{ 
	public void print_geek(); 
} 
class child implements three 
{ 
	@Override
	public void print_geek() { 
		System.out.println("Geeks"); 
	} 

	public void print_for() 
	{ 
		System.out.println("for"); 
	} 
} 

// Drived class 
public class Main 
{ 
	public static void main(String[] args) 
	{ 
		child c = new child(); 
		c.print_geek(); 
		c.print_for(); 
		c.print_geek(); 
	} 
} 

/*
Output:
Geeks
for
Geeks
*/


//  The problem occurs when there exist methods with same signature in both the super classes and subclass. On calling the method, the compiler cannot determine which class 
//  method to be called and even on calling which class method gets the priority.

// First Parent class 
class Parent1 
{ 
	void fun() 
	{ 
		System.out.println("Parent1"); 
	} 
} 

// Second Parent Class 
class Parent2 
{ 
	void fun() 
	{ 
		System.out.println("Parent2"); 
	} 
} 

// Error : Test is inheriting from multiple 
// classes 
class Test extends Parent1, Parent2 
{ 
	public static void main(String args[]) 
	{ 
		Test t = new Test(); 
		t.fun(); 
	} 
} 

/*
Output :
Compiler Error
*/


//Diamond Problem

// A Grand parent class in diamond 
class GrandParent 
{ 
	void fun() 
	{ 
		System.out.println("Grandparent"); 
	} 
} 

// First Parent class 
class Parent1 extends GrandParent 
{ 
	void fun() 
	{ 
		System.out.println("Parent1"); 
	} 
} 

// Second Parent Class 
class Parent2 extends GrandParent 
{ 
	void fun() 
	{ 
		System.out.println("Parent2"); 
	} 
} 

// Error : Test is inheriting from multiple 
// classes 
class Test extends Parent1, Parent2 
{ 
	public static void main(String args[]) 
	{ 
		Test t = new Test(); 
		t.fun(); 
	} 
} 


						//How are above problems handled for Default Methods and Interfaces ?

//Java 8 supports default methods where interfaces can provide default implementation of methods. And a class can implement two or more interfaces. 
//In case both the implemented interfaces contain default methods with same method signature, the implementing class should explicitly specify which default method 
//is to be used or it should override the default method.


// A simple Java program to demonstrate multiple 
// inheritance through default methods. 
interface PI1 
{ 
	// default method 
	default void show() 
	{ 
		System.out.println("Default PI1"); 
	} 
} 

interface PI2 
{ 
	// Default method 
	default void show() 
	{ 
		System.out.println("Default PI2"); 
	} 
} 

// Implementation class code 
class TestClass implements PI1, PI2 
{ 
	// Overriding default show method 
	public void show() 
	{ 
		// use super keyword to call the show 
		// method of PI1 interface 
		PI1.super.show(); 

		// use super keyword to call the show 
		// method of PI2 interface 
		PI2.super.show(); 
	} 

	public static void main(String args[]) 
	{ 
		TestClass d = new TestClass(); 
		d.show(); 
	} 
} 


//If there is a diamond through interfaces, then there is no issue if none of the middle interfaces provide implementation of root interface. 
//If they provide implementation, then implementation can be accessed as above using super keyword.

// A simple Java program to demonstrate how diamond 
// problem is handled in case of default methods 

interface GPI 
{ 
	// default method 
	default void show() 
	{ 
		System.out.println("Default GPI"); 
	} 
} 

interface PI1 extends GPI { } 

interface PI2 extends GPI { } 

// Implementation class code 
class TestClass implements PI1, PI2 
{ 
	public static void main(String args[]) 
	{ 
		TestClass d = new TestClass(); 
		d.show(); 
	} 
} 


// 5. Hybrid Inheritance(Through Interfaces) : It is a mix of two or more of the above types of inheritance. Since java doesn’t support multiple inheritance with classes, 
//    the hybrid inheritance is also not possible with classes. In java, we can achieve hybrid inheritance only through Interfaces.


													//Important facts about inheritance in Java

//Default superclass: In the absence of any other explicit superclass, every class is implicitly a subclass of Object class.
//Superclass can only be one: A superclass can have any number of subclasses. But a subclass can have only one superclass. 
//Inheriting Constructors: A subclass inherits all the members (fields, methods, and nested classes) from its superclass. 
						 //Constructors are not members, so they are not inherited by subclasses, but the constructor of the superclass can be invoked from the subclass.
//Private member inheritance: A subclass does not inherit the private members of its parent class. However, if the superclass has public or protected methods(like getters and setters) 
							//for accessing its private fields, these can also be used by the subclass.

//We can write a new instance method in the subclass that has the same signature as the one in the superclass, thus overriding it (as in example above, toString() method is overridden).
//We can write a new static method in the subclass that has the same signature as the one in the superclass, thus hiding it.
//We can write a subclass constructor that invokes the constructor of the superclass, either implicitly or by using the keyword super.




























