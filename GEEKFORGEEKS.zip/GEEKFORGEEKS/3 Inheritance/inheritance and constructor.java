
// Inheritance and Constructor

//In Java, constructor of base class with no argument gets automatically called in derived class constructor. For example, output of following program is:
		//Base Class Constructor Called
		//Derived Class Constructor Called
		
// filename: Main.java 
class Base { 
	Base() { 
		System.out.println("Base Class Constructor Called "); 
	} 
} 

class Derived extends Base { 
	Derived() { 
		System.out.println("Derived Class Constructor Called "); 
	} 
} 

public class Main { 
	public static void main(String[] args) { 
		Derived d = new Derived(); 
	} 
} 


//But, if we want to call parameterized constructor of base class, then we can call it using super(). The point to note is base class constructor call must be the 
//first line in derived class constructor. For example, in the following program, super(_x) is first line derived class constructor.

// filename: Main.java 
class Base { 
	int x; 
	Base(int _x) { 
		x = _x; 
	} 
} 

class Derived extends Base { 
	int y; 
	Derived(int _x, int _y) { 
		super(_x); 
		y = _y; 
	} 
	void Display() { 
		System.out.println("x = "+x+", y = "+y); 
	} 
} 

public class Main { 
	public static void main(String[] args) { 
		Derived d = new Derived(10, 20); 
		d.Display(); 
	} 
} 

												//Why Constructors are not inherited in Java?
									
//Constructor is a block of code that allows you to create an object of class and has same name as class with no explicit return type.
//Whenever a class (child class) extends another class (parent class), the sub class inherits state and behavior in the form of variables and methods from its super class 
//but it does not inherit constructor of super class because of following reasons:
		//Constructors are special and have same name as class name. So if constructors were inherited in child class then child class would contain a parent class constructor 
		//which is against the constraint that constructor should have same name as class name. 
		//For example see the below code:
		
class Parent { 
	public Parent() 
	{ 
	} 
	public void print() 
	{ 
	} 
} 

public class Child extends Parent { 
	public Parent() 
	{ 
	} 
	public void print() 
	{ 
	} 
	public static void main(String[] args) 
	{ 
		Child c1 = new Child(); // allowed 
		Child c2 = new Parent(); // not allowed 
	} 
} 

		//If we define Parent class constructor inside Child class it will give compile time error for return type and consider it a method. 
		//But for print method it does not give any compile time error and consider it a overriding method.
		
		//Now suppose if constructors can be inherited then it will be impossible to achieving encapsulation. Because by using a super class’s constructor we can 
		//access/initialize private members of a class.
		//A constructor cannot be called as a method. It is called when object of the class is created so it does not make sense of creating child class object using parent 
		//class constructor notation. i.e. Child c = new Parent();
		//A parent class constructor is not inherited in child class and this is why super() is added automatically in child class constructor if there is no explicit 
		//call to super or this.




















































































